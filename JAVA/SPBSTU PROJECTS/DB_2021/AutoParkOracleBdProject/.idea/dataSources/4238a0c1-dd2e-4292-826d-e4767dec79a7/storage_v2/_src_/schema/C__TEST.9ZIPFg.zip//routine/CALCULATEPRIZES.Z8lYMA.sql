create PROCEDURE CalculatePrizes(start_date IN DATE, end_date IN DATE, prize_sum IN VARCHAR) IS
    first_result                             NUMBER;
    second_result                            NUMBER; third_result NUMBER; current_result NUMBER; CURSOR personnel_cursor IS
        SELECT id
        FROM auto_personnel; first_driver_id personnel_cursor%ROWTYPE; second_driver_id personnel_cursor%ROWTYPE;
    third_driver_id                          personnel_cursor%ROWTYPE;
BEGIN
    IF NOT personnel_cursor%ISOPEN THEN OPEN personnel_cursor; END IF; FETCH personnel_cursor INTO first_driver_id;
    FETCH personnel_cursor INTO second_driver_id; FETCH personnel_cursor INTO third_driver_id;
    CLOSE personnel_cursor;
    FOR personnel IN personnel_cursor
        LOOP
            IF personnel.id = first_driver_id.id THEN CONTINUE; END IF;
            FindRecord(personnel.id, first_driver_id.id, start_date, end_date, current_result);
            IF current_result > 0 THEN first_driver_id := personnel; CONTINUE; END IF;

            IF personnel.id = second_driver_id.id THEN CONTINUE; END IF;
            FindRecord(personnel.id, second_driver_id.id, start_date, end_date, current_result);
            IF current_result > 0 THEN second_driver_id := personnel; CONTINUE; END IF;
            IF personnel.id = third_driver_id.id THEN CONTINUE; END IF;
            FindRecord(personnel.id, third_driver_id.id, start_date, end_date, current_result);
            IF current_result > 0 THEN third_driver_id := personnel; CONTINUE; END IF;
        END LOOP;
    first_result := prize_sum * 0.5; second_result := prize_sum * 0.3; third_result := prize_sum * 0.2;
    DBMS_OUTPUT.enable; DBMS_OUTPUT.put_line('First driver: ' || first_driver_id.id || '. Sum: ' || first_result);
    DBMS_OUTPUT.put_line('Second driver: ' || second_driver_id.id || '. Sum: ' || second_result);
    DBMS_OUTPUT.put_line('Third driver: ' || third_driver_id.id || '. Sum: ' || third_result);
END;
/

