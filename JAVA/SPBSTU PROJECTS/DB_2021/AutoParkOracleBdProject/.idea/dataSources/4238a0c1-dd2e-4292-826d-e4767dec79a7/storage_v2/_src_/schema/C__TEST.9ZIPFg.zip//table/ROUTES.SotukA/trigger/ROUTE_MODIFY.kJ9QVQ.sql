create trigger ROUTE_MODIFY
    before update
    on ROUTES
    for each row
DECLARE
    v_is_exist PLS_INTEGER;
    inserted_ID int;
PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
    SELECT COUNT(1) into v_is_exist FROM JOURNAL WHERE ROUTE_ID = :OLD.ID;
     IF (v_is_exist > 0) THEN
         INSERT INTO ROUTES (NAME) VALUES (:OLD.NAME) returning ID INTO inserted_ID;
         UPDATE JOURNAL SET ROUTE_ID = inserted_ID WHERE ROUTE_ID = :OLD.ID;
     end if;
    COMMIT;
END;
/

