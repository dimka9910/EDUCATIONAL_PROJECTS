create PROCEDURE MinTimeOnRoad(route_id_in IN int, car OUT int, time OUT INTERVAL DAY TO SECOND)
    IS
BEGIN
    select (TIME_IN - TIME_OUT) as lol
    into time
    FROM AUTO
             join JOURNAL J on AUTO.ID = J.AUTO_ID
    where (TIME_IN - TIME_OUT) in
          (SELECT MIN(TIME_IN - TIME_OUT) as t FROM (SELECT * FROM JOURNAL WHERE route_id = route_id_in));

    select AUTO_ID
    into car
    FROM AUTO
             join JOURNAL J on AUTO.ID = J.AUTO_ID
    where (TIME_IN - TIME_OUT) in
          (SELECT MIN(TIME_IN - TIME_OUT) as t FROM (SELECT * FROM JOURNAL WHERE route_id = route_id_in));
end;
/

