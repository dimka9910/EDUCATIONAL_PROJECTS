create PROCEDURE CountCarsInRoute  (route IN NUMBER,  cars_in_route OUT NUMBER) IS BEGIN SELECT COUNT(auto_id) INTO cars_in_route FROM journal   WHERE route_id = route AND time_in IS NULL; END;
/

