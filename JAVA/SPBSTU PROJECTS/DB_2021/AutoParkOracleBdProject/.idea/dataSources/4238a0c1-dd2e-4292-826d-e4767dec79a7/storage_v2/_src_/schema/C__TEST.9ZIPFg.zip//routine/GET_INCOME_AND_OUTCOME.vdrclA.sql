create PROCEDURE get_income_and_outcome(
    date1 IN DATE,
    date2 IN DATE,
    OUTCOME OUT NUMBER,
    INCOME OUT NUMBER
)
    IS
BEGIN

END;
/

