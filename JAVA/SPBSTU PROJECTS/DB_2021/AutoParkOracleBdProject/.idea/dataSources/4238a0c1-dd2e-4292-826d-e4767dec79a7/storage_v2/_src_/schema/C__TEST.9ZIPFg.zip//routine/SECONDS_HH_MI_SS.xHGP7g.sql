create function seconds_hh_mi_ss (seconds in number)
    return varchar2
    is
    hours_var number;
minutes_var number;
seconds_var number;
remeinder_var number;
output_var varchar2(32);
begin
    select seconds - mod(seconds,60) into hours_var from dual;
    select seconds - hours_var into remeinder_var from dual;
    select (remeinder_var - mod(remeinder_var,1)) into minutes_var from dual;
    select seconds - (hours_var+minutes_var) into seconds_var from dual;
    output_var := hours_var/60||':'||minutes_var/60||':'|| 0;
    return(output_var);
end;
/

