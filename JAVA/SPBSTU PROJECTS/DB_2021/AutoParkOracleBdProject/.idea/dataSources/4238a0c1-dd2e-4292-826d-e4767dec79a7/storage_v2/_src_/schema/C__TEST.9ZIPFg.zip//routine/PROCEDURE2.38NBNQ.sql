create PROCEDURE procedure2(car1 in int, car2 in int) IS
    CURSOR cur1 IS
        SELECT ROUTE_ID
        FROM (
                 SELECT ROUTE_ID, AUTO_ID, MIN(TIME_IN - TIME_OUT) time
                 FROM JOURNAL
                 WHERE AUTO_ID = car1
                   AND TIME_IN IS NOT NULL
                 GROUP BY ROUTE_ID, AUTO_ID

                 UNION

                 SELECT ROUTE_ID, AUTO_ID, MIN(TIME_IN - TIME_OUT) time
                 FROM JOURNAL
                 WHERE AUTO_ID = car2
                   AND TIME_IN IS NOT NULL
                 GROUP BY ROUTE_ID, AUTO_ID
             )

                 JOIN

             (SELECT MIN(TIME) as ttt, ROUTE_ID as nnn
              FROM (
                       SELECT ROUTE_ID, AUTO_ID, MIN(TIME_IN - TIME_OUT) time
                       FROM JOURNAL jj
                       WHERE AUTO_ID = car1
                         AND TIME_IN IS NOT NULL AND EXISTS(SELECT * FROM JOURNAL WHERE JOURNAL.AUTO_ID = car2 AND JOURNAL.ROUTE_ID = jj.ROUTE_ID AND TIME_IN IS NOT NULL )
                       GROUP BY ROUTE_ID, AUTO_ID

                       UNION

                       SELECT ROUTE_ID, AUTO_ID, MIN(TIME_IN - TIME_OUT) time
                       FROM JOURNAL jj
                       WHERE AUTO_ID = car2
                         AND TIME_IN IS NOT NULL AND EXISTS(SELECT * FROM JOURNAL WHERE JOURNAL.AUTO_ID = car1 AND JOURNAL.ROUTE_ID = jj.ROUTE_ID AND TIME_IN IS NOT NULL )
                       GROUP BY ROUTE_ID, AUTO_ID
                   )
              GROUP BY ROUTE_ID)
             on time = ttt and ROUTE_ID = nnn;
    var2 long;
BEGIN

    DBMS_OUTPUT.PUT_LINE('Маршрут    ');
    DBMS_OUTPUT.PUT_LINE('------------------------------------------------------------- ');
    OPEN cur1;
    LOOP
        FETCH cur1 INTO var2;
        EXIT WHEN cur1%NOTFOUND;
        DBMS_OUTPUT.PUT_LINE(var2);
    END LOOP;
    CLOSE cur1;
end;
/

