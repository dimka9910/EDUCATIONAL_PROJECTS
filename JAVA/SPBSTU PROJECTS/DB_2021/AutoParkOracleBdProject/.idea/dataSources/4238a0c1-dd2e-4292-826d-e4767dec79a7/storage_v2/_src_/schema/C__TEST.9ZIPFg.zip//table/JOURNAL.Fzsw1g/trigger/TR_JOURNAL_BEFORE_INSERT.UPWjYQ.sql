create trigger TR_JOURNAL_BEFORE_INSERT
    before update
    on JOURNAL
    for each row
BEGIN   IF :OLD.time_out > :NEW.time_in THEN     RAISE_APPLICATION_ERROR(-20003, 'Время прибытия не может быть меньше времени отправки');   END IF; END;
/

