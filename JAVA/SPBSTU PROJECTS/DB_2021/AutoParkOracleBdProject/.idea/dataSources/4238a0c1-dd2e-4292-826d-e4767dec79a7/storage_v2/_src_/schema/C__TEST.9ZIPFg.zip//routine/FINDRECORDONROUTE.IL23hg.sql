create PROCEDURE FindRecordOnRoute(new_route_id IN NUMBER, car_num OUT VARCHAR, min_time OUT VARCHAR)
    IS
BEGIN
    SELECT num, TO_CHAR(MIN(time_in - time_out))
    INTO car_num, min_time
    FROM journal
             JOIN auto ON journal.auto_id = auto.id
             JOIN routes ON journal.route_id = routes.id
    WHERE ROUTE_ID = new_route_id

      AND time_in IS NOT NULL
    GROUP BY num
    ORDER BY min_time FETCH FIRST 1 ROWS ONLY;
    DBMS_OUTPUT.enable; DBMS_OUTPUT.put_line('CAR NUMBER: ' || car_num || '. TIME: ' || min_time);
END;
/

