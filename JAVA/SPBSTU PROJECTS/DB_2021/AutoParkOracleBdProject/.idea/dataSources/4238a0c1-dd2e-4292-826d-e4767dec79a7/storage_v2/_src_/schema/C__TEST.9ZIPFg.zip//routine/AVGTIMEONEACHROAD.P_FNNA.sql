create PROCEDURE AvgTimeOnEachRoad IS
    CURSOR cur1 IS
        SELECT NAME,
               AVG(
                   + EXTRACT(MINUTE FROM INTRVL)
                   + EXTRACT(HOUR FROM INTRVL) * 60
                   + EXTRACT(DAY FROM INTRVL) * 60 * 24) AVERAGE
        FROM (
                 SELECT (TIME_IN - TIME_OUT) INTRVL, NAME
                 FROM ROUTES
                          LEFT JOIN JOURNAL J on ROUTES.ID = J.ROUTE_ID WHERE TIME_IN IS NOT NULL
             )
        GROUP BY NAME;
    var1 varchar2(50);
    var2 long;
BEGIN
    DBMS_OUTPUT.PUT_LINE('Маршрут    ' || '   Среднее время в пути');
    DBMS_OUTPUT.PUT_LINE('------------------------------------------------------------- ');
    OPEN cur1;
    LOOP
        FETCH cur1 INTO var1,var2;
        DBMS_OUTPUT.PUT_LINE(var1 || '          ' || var2);
        EXIT WHEN cur1%NOTFOUND;
    END LOOP;
    CLOSE cur1;
END;
/

