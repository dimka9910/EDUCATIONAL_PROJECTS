create trigger CAR_IN_TRIP
    before insert
    on JOURNAL
    for each row
DECLARE
    v_is_exist PLS_INTEGER;
BEGIN
    SELECT COUNT(1) into v_is_exist FROM JOURNAL WHERE TIME_IN is NULL AND AUTO_ID = :NEW.AUTO_ID;
    IF (v_is_exist > 0)  THEN
        RAISE_APPLICATION_ERROR(-20000, 'THIS CAR IS ALREADY IN TRIP');
    end if;
END;
/

