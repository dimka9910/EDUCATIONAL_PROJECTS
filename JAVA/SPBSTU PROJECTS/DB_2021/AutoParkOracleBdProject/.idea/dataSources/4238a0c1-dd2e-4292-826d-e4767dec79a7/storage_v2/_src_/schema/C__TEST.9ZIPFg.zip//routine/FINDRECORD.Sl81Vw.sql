create PROCEDURE FindRecord(driver1 IN NUMBER, driver2 IN NUMBER, start_date IN DATE, end_date IN DATE,
                                       routes OUT NUMBER) IS
    time1 VARCHAR(50); time2 VARCHAR(50); routes1 NUMBER; routes2 NUMBER;
BEGIN
    routes1 := 0; routes2 := 0;
    FOR item IN (SELECT ID FROM routes)
        LOOP
            BEGIN
                SELECT TO_CHAR(MIN(time_in - time_out))
                INTO time1
                FROM routes,
                     journal
                WHERE routes.id = journal.route_id
                  AND auto_id IN (SELECT id FROM auto WHERE personnel_id = driver1)
                  AND time_in IS NOT NULL
                  AND time_out > start_date
                  AND time_in < end_date
                  AND route_id = item.id;
                SELECT TO_CHAR(MIN(time_in - time_out))
                INTO time2
                FROM routes,
                     journal
                WHERE routes.id = journal.route_id
                  AND auto_id IN (SELECT id FROM auto WHERE personnel_id = driver2)
                  AND time_in IS NOT NULL
                  AND time_out > start_date
                  AND time_in < end_date
                  AND route_id = item.id;
                IF time1 IS NULL AND time2 IS NOT NULL THEN routes2 := routes2 + 1; END IF;
                IF time1 IS NOT NULL AND time2 IS NULL THEN routes1 := routes1 + 1; END IF;
                IF time1 IS NOT NULL AND time2 IS NOT NULL AND (time1) < (time2) THEN routes1 := routes1 + 1; END IF;
            EXCEPTION
                WHEN NO_DATA_FOUND THEN CONTINUE;
            END;
        END LOOP;
    routes := routes1 - routes2;
END;
/

