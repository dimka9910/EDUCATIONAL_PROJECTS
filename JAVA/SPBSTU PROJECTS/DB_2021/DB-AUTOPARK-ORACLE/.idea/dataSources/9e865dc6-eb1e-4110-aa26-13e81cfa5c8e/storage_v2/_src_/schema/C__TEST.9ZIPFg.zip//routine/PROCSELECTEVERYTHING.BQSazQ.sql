create PROCEDURE ProcSelectEveryThing(cursor_ OUT SYS_REFCURSOR)
AS
BEGIN
    OPEN cursor_ FOR
        SELECT NAME, NUM, MIN(TIME_IN - TIME_OUT) time
        FROM JOURNAL
                 JOIN AUTO A2 on A2.ID = JOURNAL.AUTO_ID
                 JOIN ROUTES R on R.ID = JOURNAL.ROUTE_ID
        WHERE A2.NUM = 'NUM №3'
          AND TIME_IN IS NOT NULL
        GROUP BY NAME, NUM;
END;
/

