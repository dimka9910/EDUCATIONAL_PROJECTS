create trigger DRIVER_DELETE
    before delete
    on AUTO_PERSONNEL
    for each row
DECLARE
    v_is_exist PLS_INTEGER;
BEGIN
    SELECT COUNT(1) into v_is_exist FROM AUTO WHERE PERSONNEL_ID = :OLD.ID;
    IF (v_is_exist > 0)  THEN
        RAISE_APPLICATION_ERROR(-20000, 'THIS DRIVER HAS REFERENCES IN OTHER TABLES');
    end if;
END;
/

