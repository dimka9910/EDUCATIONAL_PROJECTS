create PROCEDURE MinTimeOnRoad(route_id_in IN int, car OUT VARCHAR2, time OUT INTERVAL DAY TO SECOND)
    IS
BEGIN
    select (TIME_IN - TIME_OUT) as lol into time FROM AUTO join JOURNAL J on AUTO.ID = J.AUTO_ID where (TIME_IN - TIME_OUT) = (SELECT MIN(TIME_IN - TIME_OUT) as t FROM (SELECT * FROM JOURNAL WHERE route_id = route_id_in));

    select NUM into car FROM AUTO join JOURNAL J on AUTO.ID = J.AUTO_ID where (TIME_IN - TIME_OUT) = (SELECT MIN(TIME_IN - TIME_OUT) as t FROM (SELECT * FROM JOURNAL WHERE route_id = route_id_in));
end;
/

