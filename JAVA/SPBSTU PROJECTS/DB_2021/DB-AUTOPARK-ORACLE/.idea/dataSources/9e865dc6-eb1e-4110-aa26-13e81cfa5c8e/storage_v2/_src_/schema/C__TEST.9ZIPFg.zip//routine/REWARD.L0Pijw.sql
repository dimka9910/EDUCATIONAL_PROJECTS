create PROCEDURE reward(from1 in TIMESTAMP,
                                   to2 in TIMESTAMP,
                                   totalReward in NUMBER,
                                   Id1 OUT NUMBER,
                                   Id2 OUT NUMBER,
                                   Id3 OUT NUMBER,
                                   reward1 OUT float,
                                   reward2 OUT float,
                                   reward3 OUT float)
    IS
    CURSOR PERSONNEL
        IS
        SELECT COUNT(PERSONNEL_ID) as ccc, PERSONNEL_ID FROM (SELECT ROUTE_ID, MIN(TIME_IN - TIME_OUT) tutu
                                                              FROM JOURNAL
                                                                       JOIN AUTO A2 on JOURNAL.AUTO_ID = A2.ID
                                                              where TIME_IN is not NULL AND TIME_OUT BETWEEN from1 AND to2
                                                              GROUP BY ROUTE_ID) JOIN
                                                             (SELECT (TIME_IN - TIME_OUT) as titi, ROUTE_ID, PERSONNEL_ID
                                                              FROM JOURNAL
                                                                       JOIN AUTO A2 on JOURNAL.AUTO_ID = A2.ID
                                                              where TIME_IN is not NULL AND PERSONNEL_ID is not null
                                                             ) on tutu = titi GROUP BY PERSONNEL_ID ORDER BY ccc DESC;
    topCount     number;
    currentPersonnelId number;
    counter number:= 0;

    TYPE array_t IS TABLE OF NUMBER  -- Associative array type
        INDEX BY VARCHAR2(64);
BEGIN

    counter := 0;
    Id1 := -1;
    Id2 := -1;
    Id3 := -1;

    open PERSONNEL;
    LOOP
        FETCH PERSONNEL INTO topCount, currentPersonnelId;
        EXIT WHEN PERSONNEL%NOTFOUND OR counter = 3;
        counter := counter + 1;
        if (Id1 < 0) then
            Id1 := currentPersonnelId;
        ELSIF
            (Id2 < 0) then
            Id2 := currentPersonnelId;
        ELSIF
            (Id3 < 0) then
            Id3 := currentPersonnelId;
        end if;
    end loop;
    close PERSONNEL;


    reward1 := totalReward * 0.5;
    reward2 := totalReward * 0.3;
    reward3 := totalReward * 0.2;
END;
/

